<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="columns">
        <div class="column is-three-fifths is-offset-one-fifth">
            <div class="box">
                <h2 class="title">Login</h2>

                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="field">
                        <p class="control has-icons-left has-icons-right">
                            <input class="input <?php echo e($errors->has('email') ? ' is-danger' : ''); ?>" type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                            <span class="icon is-small is-left">
                                <i class="fa fa-envelope"></i>
                            </span>
                        </p>
                        <?php if($errors->has('email')): ?>
                            <p class="help is-danger">
                                <?php echo e($errors->first('email')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="field">
                        <p class="control has-icons-left">
                            <input class="input <?php echo e($errors->has('password') ? ' is-danger' : ''); ?>" type="password" name="password" placeholder="Password" required>
                            <span class="icon is-small is-left">
                                <i class="fa fa-lock"></i>
                            </span>
                        </p>
                        <?php if($errors->has('password')): ?>
                            <p class="help is-danger">
                                <?php echo e($errors->first('password')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="field">
                        <p class="control">
                            <label class="checkbox">
                                <input type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                Remember me
                            </label>
                        </p>
                    </div>
                    <div class="field">
                        <p class="control">
                            <a href="<?php echo e(route('password.request')); ?>">
                                Forgot Your Password?
                            </a>
                        </p>
                    </div>
                    <div class="field">
                        <p class="control">
                            <a class="button is-primary" href="<?php echo e(route('register')); ?>">
                                Register
                            </a>
                            <button class="button is-primary">
                                Login
                            </button>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>