<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="columns">
        <div class="column is-three-fifths is-offset-one-fifth">
            <div class="box">
                <h2 class="title">Register</h2>

                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="field">
                        <p class="control has-icons-left has-icons-right">
                            <input class="input <?php echo e($errors->has('name') ? ' is-danger' : ''); ?>" type="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="Name">
                            <span class="icon is-small is-left">
                                <i class="fa fa-user-o"></i>
                            </span>
                        </p>
                        <?php if($errors->has('name')): ?>
                            <p class="help is-danger">
                                <?php echo e($errors->first('name')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="field">
                        <p class="control has-icons-left has-icons-right">
                            <input class="input <?php echo e($errors->has('email') ? ' is-danger' : ''); ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                            <span class="icon is-small is-left">
                                <i class="fa fa-envelope"></i>
                            </span>
                        </p>
                        <?php if($errors->has('email')): ?>
                            <p class="help is-danger">
                                <?php echo e($errors->first('email')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="field">
                        <p class="control has-icons-left">
                            <input class="input <?php echo e($errors->has('password') ? ' is-danger' : ''); ?>" type="password" name="password" placeholder="Password">
                            <span class="icon is-small is-left">
                                <i class="fa fa-lock"></i>
                            </span>
                        </p>
                        <?php if($errors->has('password')): ?>
                            <p class="help is-danger">
                                <?php echo e($errors->first('password')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="field">
                        <p class="control has-icons-left">
                            <input id="password-confirm" type="password" class="input" name="password_confirmation" placeholder="Confirm password">
                            <span class="icon is-small is-left">
                                <i class="fa fa-lock"></i>
                            </span>
                        </p>
                    </div>
                    <div class="field">
                        <p class="control">
                            <button type="submit" class="button is-primary">
                                Register
                            </a>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>