function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#img')
                .attr('src', e.target.result)
                .width(150)
                .height(200);
        };

        reader.readAsDataURL(input.files[0]);
    }
}


//
// $(document).ready(function() {
//     var brand = document.getElementById('imgname');
//     brand.className = 'custom-file-label';
//     brand.onchange = function() {
//         document.getElementById('imgname').value = this.value.substring(12);
//     };
//
//     // Source: http://stackoverflow.com/a/4459419/6396981
//     function readURL(input) {
//         if (input.files && input.files[0]) {
//             var reader = new FileReader();
//
//             reader.onload = function(e) {
//                 $('.img-preview11').attr('src', e.target.result);
//             };
//             reader.readAsDataURL(input.files[0]);
//         }
//     }
//     $("#inputGroupFile02").change(function() {
//         readURL(this);
//     });
// });
