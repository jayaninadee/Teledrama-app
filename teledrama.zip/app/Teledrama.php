<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teledrama extends Model
{
    //
    protected $table='teledramas';
//    protected $fillable=['te_Name','te_Image'];
}

